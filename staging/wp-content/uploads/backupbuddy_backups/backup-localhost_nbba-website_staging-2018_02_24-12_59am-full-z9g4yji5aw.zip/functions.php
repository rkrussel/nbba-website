<?php
/**
 * Grand Slam
 *
 * This file adds functions to the Grand Slam Theme.
 *
 * @package Grand Slam
 * @author  National Beep Baseball Association Web Team
 * @license GPL-2.0+
 * @link    https://www.nbba.org/
 */

// Start the engine.
include_once( get_template_directory() . '/lib/init.php' );

// Setup Theme.
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

/** Enqueue secondary stylesheet for custom styling **/

add_action( 'wp_enqueue_scripts', 'nbba_custom_styles' );

function nbba_custom_styles() {

	wp_enqueue_style( 'custom-stylesheet', CHILD_URL . '/lib/custom.css', array(), PARENT_THEME_VERSION );
}

// Child theme (do not remove).
define( 'CHILD_THEME_NAME', 'Grand Slam' );
define( 'CHILD_THEME_URL', 'https://www.nbba.org/resources/teams/grand-slam/' );
define( 'CHILD_THEME_VERSION', '1.0' );

// Enqueue Scripts and Styles.

// Add HTML5 markup structure.
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

// Add Accessibility support.
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'rems', 'search-form', 'skip-links' ) );

// Add viewport meta tag for mobile browsers.
add_theme_support( 'genesis-responsive-viewport' );

// Add support for custom header.
add_theme_support( 'custom-header', array(
	'width'           => 600,
	'height'          => 160,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );

// Add support for custom background.
add_theme_support( 'custom-background' );

// Add support for after entry widget.
add_theme_support( 'genesis-after-entry-widget-area' );

// Add support for 3-column footer widgets.
add_theme_support( 'genesis-footer-widgets', 3 );

// Add Image Sizes.
add_image_size( 'featured-image', 720, 400, TRUE );

// Rename primary and secondary navigation menus.
add_theme_support( 'genesis-menus', array( 'primary' => __( 'After Header Menu', 'genesis-sample' ), 'secondary' => __( 'Footer Menu', 'genesis-sample' ) ) );

// Reposition the secondary navigation menu.
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_footer', 'genesis_do_subnav', 5 );

// Reduce the secondary navigation menu to one level depth.
add_filter( 'wp_nav_menu_args', 'genesis_sample_secondary_menu_args' );
function genesis_sample_secondary_menu_args( $args ) {

	if ( 'secondary' != $args['theme_location'] ) {
		return $args;
	}

	$args['depth'] = 1;

	return $args;

}

// Modify size of the Gravatar in the author box.
add_filter( 'genesis_author_box_gravatar_size', 'genesis_sample_author_box_gravatar' );
function genesis_sample_author_box_gravatar( $size ) {
	return 90;
}

// Modify size of the Gravatar in the entry comments.
add_filter( 'genesis_comment_list_args', 'genesis_sample_comments_gravatar' );
function genesis_sample_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;

	return $args;

}

/** Other custom mods **/

add_action('wp_enqueue_scripts', 'nbba_extra_scripts');
function nbba_extra_scripts() {
wp_enqueue_script( 'nbba_extra_scripts', CHILD_URL . '/js/van11y-accessible-tab-panel-aria.js', false, '1.0', true );
}